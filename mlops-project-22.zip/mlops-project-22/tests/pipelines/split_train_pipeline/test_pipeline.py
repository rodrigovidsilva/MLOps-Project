"""
This is a boilerplate test file for pipeline 'split_train_pipeline'
generated using Kedro 0.19.6.
Please add your pipeline tests here.

Kedro recommends using `pytest` framework, more info about it can be found
in the official documentation:
https://docs.pytest.org/en/latest/getting-started.html
"""
import pandas as pd
from src.mlops_project_22.pipelines.split_train_pipeline.nodes import split_data  

def test_split_data():
    data = {
        'Feature1': [1, 40, 50, 40, 50, 40, 20, 90, 10, 10],
        'Feature2': [100, 10, 30, 1, 0, 3, 5, 7, 8, 9],
        'Target': [1, 0, 1, 0, 1, 1, 0, 1, 1, 0]
    }
    df = pd.DataFrame(data)
    
    parameters = {
        'target_column': 'Target',
        'test_fraction': 0.2,
        'random_state': 42
    }
    
    X_train, X_test, y_train, y_test = split_data(df, parameters)
    
    assert X_train is not None
    assert X_test is not None
    assert y_train is not None
    assert y_test is not None
    
    assert X_train.shape[0] == 8
    assert X_test.shape[0] == 2
    assert y_train.shape[0] == 8
    assert y_test.shape[0] == 2
    
    assert X_train.shape[1] == 2
    assert X_test.shape[1] == 2

