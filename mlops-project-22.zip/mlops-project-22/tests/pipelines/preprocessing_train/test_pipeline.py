"""
This is a boilerplate test file for pipeline 'preprocessing_train'
generated using Kedro 0.19.6.
Please add your pipeline tests here.

Kedro recommends using `pytest` framework, more info about it can be found
in the official documentation:
https://docs.pytest.org/en/latest/getting-started.html
"""
import pandas as pd
from src.mlops_project_22.pipelines.preprocessing_train.nodes import feature_engineer  # Replace 'your_module' with actual module name

def test_feature_engineer():
    data = {
        'age': [25, 40, 55],
        'trtbps': [110, 150, 135],
        'chol': [200, 250, 180],
        'sex': ['male', 'female', 'male'],
        'exng': ['yes', 'no', 'yes'],
        'caa': [0, 1, 2],
        'cp': [1, 0, 2],
        'fbs': [1, 0, 1],
        'restecg': [0, 1, 0],
        'slp': [2, 1, 2],
        'thall': [3, 2, 1],
        'thalachh': [1,1,1],
        'oldpeak': [2,3,4]
    }
    df = pd.DataFrame(data)

    df_transformed = feature_engineer(df)

    assert 'chol_zscore' in df_transformed.columns
    assert df_transformed.shape[1] > len(data.keys())