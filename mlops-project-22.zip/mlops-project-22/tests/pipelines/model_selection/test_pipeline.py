import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from src.mlops_project_22.pipelines.model_selection.nodes import model_selection

def test_model_selection():
    X, y = make_classification(n_samples=100, n_features=20, random_state=42)
    X = pd.DataFrame(X, columns=[f'feat_{i}' for i in range(X.shape[1])])
    y = pd.Series(y, name='target')
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    parameters = {'hyperparameters': {
            'RandomForestClassifier': {'n_estimators': [10, 50]},
            'DecisionTreeClassifier': {'max_depth': [3, 5]},
            'LogisticRegression': {'C': [0.1, 1.0]}}}
    
    best_columns = X_train.columns 

    champion_dict = {
        'classifier': 'RandomForestClassifier',
        'test_score': [0.85, 0.9]}
    
    results = model_selection(X_train, X_test, y_train, y_test, best_columns, champion_dict, parameters)
    assert isinstance(results, dict)
    for classifier, info in results.items():
        assert 'model' in results
        assert 'scores' in results
