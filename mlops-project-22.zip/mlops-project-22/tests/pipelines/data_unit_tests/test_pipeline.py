"""
This is a boilerplate test file for pipeline 'data_unit_tests'
generated using Kedro 0.19.6.
Please add your pipeline tests here.

Kedro recommends using `pytest` framework, more info about it can be found
in the official documentation:
https://docs.pytest.org/en/latest/getting-started.html
"""
import pandas as pd
from src.mlops_project_22.pipelines.data_unit_tests.nodes import build_expectation_suite

def test_build_expectation_suite():
    """Test the build_expectation_suite function."""
    
    expectation_suite_name = "TestExpectations"
    data = pd.DataFrame({
        'age': [25, 30, 35, 40, 45],
        'sex': [0, 1, 0, 1, 0],
        'cp': [0, 1, 2, 3, 0],
        'trtbps': [120, 130, 140, 150, 160],
        'chol': [200, 220, 240, 260, 280],
        'fbs': [0, 1, 0, 1, 0],
        'restecg': [0, 1, 2, 0, 1],
        'thalachh': [160, 170, 180, 190, 200],
        'exng': [0, 1, 0, 1, 0],
        'oldpeak': [1.0, 2.0, 3.0, 4.0, 5.0],
        'slp': [0, 1, 2, 0, 1],
        'caa': [0, 1, 2, 3, 4],
        'thall': [0, 1, 2, 3, 0],
        'output': [0, 1, 0, 1, 0]
    })

    suite = build_expectation_suite(expectation_suite_name, data)
    assert suite is not None



