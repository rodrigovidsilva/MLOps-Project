"""
This is a boilerplate test file for pipeline 'ingestion'
generated using Kedro 0.19.6.
Please add your pipeline tests here.

Kedro recommends using `pytest` framework, more info about it can be found
in the official documentation:
https://docs.pytest.org/en/latest/getting-started.html
"""
import pandas as pd
from src.mlops_project_22.pipelines.ingestion.nodes import ingestion

def test_ingestion():
    df = pd.DataFrame({
        'A': [1, 2, 3],
        'B': [4, 5, 6]})
    
    df_new = pd.DataFrame({
        'A': [7, 8,3],
        'B': [9, 10,7]})

    ingested = ingestion(df, df_new)

    expected_columns = ['index', 'A', 'B']
    expected_data = {
        'index': [0, 1, 2, 3,4,5],
        'A': [1, 2, 3, 7, 8,3],
        'B': [4, 5, 6, 9, 10,7]
    }
    expected_ingested = pd.DataFrame(expected_data, columns=expected_columns)

    pd.testing.assert_frame_equal(ingested, expected_ingested)

    assert ingested.columns.tolist() == expected_columns
    assert ingested.index.tolist() == expected_ingested.index.tolist()