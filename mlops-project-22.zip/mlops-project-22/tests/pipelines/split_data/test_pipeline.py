"""
This is a boilerplate test file for pipeline 'split_data'
generated using Kedro 0.19.6.
Please add your pipeline tests here.

Kedro recommends using `pytest` framework, more info about it can be found
in the official documentation:
https://docs.pytest.org/en/latest/getting-started.html
"""
import pandas as pd
from src.mlops_project_22.pipelines.split_data.nodes import split_heart_random
def test_split_heart_random():
    data = {
        'Feature1': [1, 40, 50, 40, 50, 40, 20, 90, 10, 10],
        'Feature2': [100, 10, 30, 1, 0, 3, 5, 7, 8, 9],
        'Target': [1, 0, 1, 0, 1, 1, 0, 1, 1, 0]
    }
    df = pd.DataFrame(data)
    
    ref_heart, ana_heart = split_heart_random(df)
    
    assert ref_heart is not None
    assert ana_heart is not None
    
    assert ref_heart.shape[0] == 8
    assert ana_heart.shape[0] == 2
    
    assert ref_heart.shape[1] == df.shape[1]
    assert ana_heart.shape[1] == df.shape[1]