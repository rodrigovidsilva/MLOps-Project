"""
This is a boilerplate test file for pipeline 'model_train'
generated using Kedro 0.19.6.
Please add your pipeline tests here.

Kedro recommends using `pytest` framework, more info about it can be found
in the official documentation:
https://docs.pytest.org/en/latest/getting-started.html
"""
import pandas as pd
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression


from src.mlops_project_22.pipelines.model_train.nodes import model_train 

def test_model_train():
    X, y = make_classification(n_samples=100, n_features=15, random_state=42)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    X_train = pd.DataFrame(X_train, columns=[f"feature_{i}" for i in range(X_train.shape[1])])
    X_test = pd.DataFrame(X_test, columns=[f"feature_{i}" for i in range(X_test.shape[1])])

    best_columns = [f"feature_{num}" for num in range(1, 5)]
    
    model, trained_columns, results_dict = model_train(X_train, X_test, y_train, y_test, best_columns)

    assert isinstance(model, (RandomForestClassifier, DecisionTreeClassifier, LogisticRegression))
    assert len(results_dict['test_score']) == 4
    assert all(feature in X_train.columns for feature in best_columns)

