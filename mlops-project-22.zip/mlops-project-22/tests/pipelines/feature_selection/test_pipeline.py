"""
This is a boilerplate test file for pipeline 'feature_selection'
generated using Kedro 0.19.6.
Please add your pipeline tests here.

Kedro recommends using `pytest` framework, more info about it can be found
in the official documentation:
https://docs.pytest.org/en/latest/getting-started.html
"""
import pandas as pd
import logging
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from src.mlops_project_22.pipelines.feature_selection.nodes import feature_selection  

def test_feature_selection():
    X, y = make_classification(n_samples=100, n_features=20, random_state=42)
    X = pd.DataFrame(X, columns=[f'feat_{i}' for i in range(X.shape[1])])
    X['index'] = [i for i in range(1,101)]
    y = pd.Series(y, name='target')

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    params = {
        "threshold": 0.1, 
        "k": 10,           
        "top_k": 5         
    }

    selected_features = feature_selection(X_train, y_train, params)

    assert isinstance(selected_features, list)
    assert len(selected_features) == params["top_k"]
    assert all(feature in X_train.columns for feature in selected_features)
