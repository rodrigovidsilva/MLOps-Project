"""mlops_project_22
"""

__version__ = "0.1"
