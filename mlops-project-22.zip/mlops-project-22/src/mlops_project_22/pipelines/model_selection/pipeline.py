"""
This is a boilerplate pipeline 'model_selection'
generated using Kedro 0.19.6
"""
from kedro.pipeline import Pipeline, node, pipeline

from .nodes import model_selection


def create_pipeline(**kwargs) -> Pipeline:
    return pipeline(
        [
            node(
                func=model_selection,
                inputs=["X_train_data","X_test_data","y_train_data","y_test_data","best_columns",
                        "production_model_metrics",
                        "parameters"],
                outputs="models_dict",
                name="model_selection",
            )
        ]
    )
