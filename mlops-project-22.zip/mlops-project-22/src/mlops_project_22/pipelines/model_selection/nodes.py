import pandas as pd
import logging
from typing import Dict, Any
import numpy as np
import yaml
import pickle
from mlflow import MlflowClient
import warnings
warnings.filterwarnings("ignore", category=Warning)

from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import accuracy_score, f1_score
import shap
import matplotlib.pyplot as plt

import mlflow

logger = logging.getLogger(__name__)

def model_selection(X_train: pd.DataFrame, 
                    X_test: pd.DataFrame, 
                    y_train: pd.DataFrame, 
                    y_test: pd.DataFrame,
                    best_columns,
                    champion_dict: Dict[str, Any],
                    parameters: Dict[str, Any]) -> Dict[str, Any]:
    
    """Trains a model on the given data and saves it to the given model path.

    Args:
    --
        X_train (pd.DataFrame): Training features.
        X_test (pd.DataFrame): Test features.
        y_train (pd.DataFrame): Training target.
        y_test (pd.DataFrame): Test target.
        parameters (dict): Parameters defined in parameters.yml.

    Returns:
    --
        models (dict): Dictionary containing trained models, scores, and parameters.
            Keys are model names (str), values are dictionaries with keys:
            - 'model': trained model object
            - 'parameters': parameters used for training
            - 'scores': scores (accuracy and f1-score) as a list [accuracy, f1-score]
    """
    X_train = X_train[best_columns]
    X_test = X_test[best_columns]
   
    models_dict = {
        'RandomForestClassifier': RandomForestClassifier(),
        'DecisionTreeClassifier': DecisionTreeClassifier(),
        'LogisticRegression': LogisticRegression(max_iter = 300),
    }

    client = MlflowClient()

 

    with open('conf/local/mlflow.yml') as f:
        experiment_name = yaml.load(f, Loader=yaml.SafeLoader)['tracking']['experiment']['name']
        experiment_id = mlflow.get_experiment_by_name(experiment_name).experiment_id
        logger.info(experiment_id)

    logger.info('Starting first step of model selection: Comparing between model types')

    # Convert y_train and y_test to 1D arrays
    y_train = y_train.values.ravel()
    y_test = y_test.values.ravel()

    models = {}

    with mlflow.start_run(nested=True):
        for model_name, model in models_dict.items():
            logger.info(f"Performing GridSearchCV for {model_name}")
            # Perform hyperparameter tuning with GridSearchCV
            param_grid = parameters['hyperparameters'].get(model_name, {})
            logger.info(f"Parameter grid: {param_grid}")
            gridsearch = GridSearchCV(model, param_grid, cv=5, scoring='accuracy', n_jobs=-1)
            gridsearch.fit(X_train, y_train)

            # Get the best model from GridSearchCV
            best_model = gridsearch.best_estimator_
            best_parameters = gridsearch.best_params_

            # Calculate accuracy on test set
            best_model_test_score_acc = accuracy_score(y_test, best_model.predict(X_test))
            best_model_test_score_f1 = f1_score(y_test, best_model.predict(X_test))
            logger.info(f"Test score for {model_name}-> with parameters: {best_parameters}")
            logger.info(f"Test score for {model_name}-> accuracy:{best_model_test_score_acc}, f1-score:{best_model_test_score_f1}")

            # Store model, scores, and parameters in dictionary
            models[model_name] = {
                'model': best_model,
                'scores': [best_model_test_score_acc, best_model_test_score_f1]
            }

        best_model_name = max(models, key=lambda model: sum(models[model]['scores']) / len(models[model]['scores']))
        logger.info(f"Best test score for {best_model_name}-> accuracy:{models[best_model_name]['scores'][0]}, f1-score:{models[best_model_name]['scores'][1]}")

        champion_score = (champion_dict['test_score'][0] + champion_dict['test_score'][-1]) / 2
        challenger_score = (models[best_model_name]['scores'][0] + models[best_model_name]['scores'][1]) / 2
        if champion_score < challenger_score:
            logger.info(f"New champion model is {best_model_name} with score-> accuracy:{models[best_model_name]['scores'][0]}, f1-score:{models[best_model_name]['scores'][1]} vs -> accuracy:{champion_dict['test_score'][0]}, f1-score:{champion_dict['test_score'][-1]}")
            client.set_registered_model_alias(f"sk-learn-{best_model_name}", "Champion", "1")
            return models[best_model_name]
        else:
            logger.info(f"Champion model is still {champion_dict['classifier']} with scores -> accuracy:{champion_dict['test_score'][0]}, f1-score:{champion_dict['test_score'][-1]}")
            return models
