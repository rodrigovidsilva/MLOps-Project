"""
This is a boilerplate pipeline 'ingestion'
generated using Kedro 0.19.6
"""
import pandas as pd

def ingestion(df, df_new):
    
    
    ingested = pd.concat([df, df_new], ignore_index=False)
    ingested = ingested.reset_index(drop=True).reset_index()

    return ingested