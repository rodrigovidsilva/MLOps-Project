"""
This is a boilerplate pipeline 'ingestion'
generated using Kedro 0.19.6
"""

from kedro.pipeline import Pipeline, pipeline
from .nodes import ingestion
from kedro.pipeline import Pipeline, node, pipeline


def create_pipeline(**kwargs) -> Pipeline:
    return pipeline([node(
                func= ingestion,
                inputs=["heart","heart_additional"],
                outputs= "ingested",
                name="ingestion_node",
            )])
