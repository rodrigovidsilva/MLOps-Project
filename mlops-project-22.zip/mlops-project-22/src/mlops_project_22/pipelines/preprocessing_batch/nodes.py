"""
This is a boilerplate pipeline 'preprocess_batch'
generated using Kedro 0.19.6
"""
import pandas as pd
import logging
from sklearn.preprocessing import StandardScaler
from scipy.stats import zscore

def create_feat(df: pd.DataFrame) -> pd.DataFrame:
    age_bins = [0, 30, 50, 65, 80, 100, 115]
    bp_bins = [0, 120, 140, 160, 180, 200]

    df['age_bin'] = pd.cut(df['age'], bins=age_bins, labels=['0-30', '31-50', '50-65', '65-80', '80-100', '100-115'])
    df['bp_bin'] = pd.cut(df['trtbps'], bins=bp_bins, labels=['0-120', '121-140', '141-160', '161-180', '181-200'])

    # Creating the profile identifier
    df['profile'] = df['age_bin'].astype(str) + '_' + df['bp_bin'].astype(str)

    # Apply Z-score normalization to the cholesterol column
    df['chol_zscore'] = zscore(df['chol'])
    df = df.drop(columns=['profile', 'age_bin', 'bp_bin'])
    return df
#data_units aqui
def encode_and_scale(df: pd.DataFrame) -> pd.DataFrame:
    cat_cols = ['sex', 'exng', 'caa', 'cp', 'fbs', 'restecg', 'slp', 'thall']
    con_cols = ["age", "trtbps", "chol", "thalachh", "oldpeak", "chol_zscore"]

    # Encoding the categorical columns
    df = pd.get_dummies(df, columns=cat_cols, drop_first=True)
    
    # Scaling the continuous columns
    scaler = StandardScaler()
    df[con_cols] = scaler.fit_transform(df[con_cols])
    #ver se da para fazer.transform
    logging.info(f"Data after encoding and scaling has {df.shape[1]} columns.")
    return df

def feature_engineer(df: pd.DataFrame):
    df = create_feat(df)
    df = encode_and_scale(df)
    #oh = df.loc[:,['sex', 'exng', 'caa', 'cp', 'fbs', 'restecg', 'slp', 'thall']]
    return df

#feature_store fazer