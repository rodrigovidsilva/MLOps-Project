"""
This is a boilerplate pipeline 'preprocess_batch'
generated using Kedro 0.19.6
"""

from kedro.pipeline import Pipeline, node ,pipeline
from .nodes import feature_engineer


def create_pipeline(**kwargs) -> Pipeline:
    return pipeline([node(
                func= feature_engineer,
                inputs="ana_heart",
                outputs= "preprocessed_batch_data",
                name="preprocessed_batch",
            )])
