import numpy as np
import pandas as pd
import os
import pickle
import logging
from sklearn.feature_selection import VarianceThreshold, SelectKBest, f_classif, mutual_info_classif
import matplotlib.pyplot as plt
import mlflow
import random



def feature_selection(X_train: pd.DataFrame, y_train: pd.DataFrame, params: dict) -> list:
    log = logging.getLogger(__name__)
    log.info(f"We start with: {len(X_train.columns)} columns")
    X_train = X_train.drop(columns=["index"])

    mlflow.log_params(params)
    
    # Step 1: Apply Variance Threshold
    vth = VarianceThreshold(threshold=params["threshold"])
    X_train_vth = X_train.iloc[:, vth.fit(X_train).get_support()]
    
    # Step 2: Apply SelectKBest (ANOVA F-value)
    Kbest_classif = SelectKBest(score_func=f_classif, k=params["k"])
    Kbest_classif.fit(X_train_vth, y_train)
    f_scores = Kbest_classif.scores_
    
    # Step 3: Apply SelectKBest (mutual information)
    infogain_classif = SelectKBest(score_func=mutual_info_classif, k=params["k"])
    infogain_classif.fit(X_train_vth, y_train)
    mi_scores = infogain_classif.scores_
    
    # Step 4: Normalize scores
    f_scores_norm = (f_scores - np.min(f_scores)) / (np.max(f_scores) - np.min(f_scores))
    mi_scores_norm = (mi_scores - np.min(mi_scores)) / (np.max(mi_scores) - np.min(mi_scores))
    
    # Step 5: Combine scores
    combined_scores = f_scores_norm + mi_scores_norm
    
    # Create a DataFrame for the combined scores
    scores_df = pd.DataFrame({
        'Feature': X_train_vth.columns,
        'F_score': f_scores,
        'MI_score': mi_scores,
        'Combined_score': combined_scores
    }).sort_values('Combined_score', ascending=False)
    
    # Select top features based on combined score
    X_cols = scores_df['Feature'].head(params["top_k"]).tolist()
    
    # Log the number of selected features and their names
    log.info(f"Number of best columns is: {len(X_cols)}")
    log.info(f"Selected top {params['top_k']} features: {X_cols}")
    mlflow.log_metric("number_of_selected_features", len(X_cols))
    
    return X_cols
