"""
This is a boilerplate pipeline 'feature_selection'
generated using Kedro 0.19.6
"""

from .pipeline import create_pipeline

__all__ = ["create_pipeline"]

__version__ = "0.1"
