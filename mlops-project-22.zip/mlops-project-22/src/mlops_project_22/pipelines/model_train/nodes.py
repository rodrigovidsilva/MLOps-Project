import pandas as pd
import logging
from typing import Dict, Any
import numpy as np
import pickle
import yaml
import os
import warnings
from datetime import datetime
warnings.filterwarnings("ignore", category=Warning)
import mlflow
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.ensemble import RandomForestClassifier,GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.inspection import permutation_importance
import random
import matplotlib.pyplot as plt
import shap
from mlflow import MlflowClient
random.seed(42)
np.random.seed(42)
logger = logging.getLogger(__name__)

def model_train(X_train: pd.DataFrame, 
                X_test: pd.DataFrame, 
                y_train: pd.DataFrame, 
                y_test: pd.DataFrame,
                best_columns):

    # Setup MLflow experiment
    with open('conf/local/mlflow.yml') as f:
        experiment_name = yaml.load(f, Loader=yaml.loader.SafeLoader)['tracking']['experiment']['name']
    experiment_id = mlflow.get_experiment_by_name(experiment_name).experiment_id
    logger.info('Starting first step of model selection: Comparing between model types')
    
    # Enable MLflow autologging
    mlflow.sklearn.autolog(log_model_signatures=True, log_input_examples=True)

    try:
        # Try to load the existing champion model
        with open(os.path.join(os.getcwd(), 'data', '06_models', 'champion_model.pkl'), 'rb') as f:
            classifier = pickle.load(f)
        logger.info(f"Our classifier in prod is: {classifier}")
    except Exception as e:
        logger.error(f"Error loading champion model: {e}")
        # If loading fails, choose a random model
        models_dict = {
            'RandomForestClassifier': RandomForestClassifier(random_state=42),
            'DecisionTreeClassifier': DecisionTreeClassifier(random_state=42),
            'LogisticRegression': LogisticRegression(random_state=42),
        }
        model_name = random.choice(list(models_dict.keys()))
        classifier = models_dict[model_name]
        logger.info(f"Using a new classifier: {classifier}")

    client = MlflowClient()
    mlflow.register_model(
    mlflow.last_active_run().info.run_id, "sk-learn-RandomForestClassifier")
    mlflow.register_model(
    mlflow.last_active_run().info.run_id, "sk-learn-DecisionTreeClassifier")
    mlflow.register_model(
    mlflow.last_active_run().info.run_id, "sk-learn-LogisticRegression")
    client.set_registered_model_tag("sk-learn-RandomForestClassifier", "task", "classification")
    client.set_registered_model_tag("sk-learn-DecisionTreeClassifier", "task", "classification")
    client.set_registered_model_tag("sk-learn-LogisticRegression", "task", "classification")

    results_dict = {}
    client.set_registered_model_alias(f"sk-learn-{model_name}", "Production", "1")
    # Start MLflow run
    with mlflow.start_run(experiment_id=experiment_id, nested=True):
        logger.info("Using feature selection in model train...")
        X_train = X_train[best_columns]
        X_test = X_test[best_columns]
        y_train = np.ravel(y_train)
        model = classifier.fit(X_train, y_train)
        
        y_test_pred = model.predict(X_test)

        # Calculate metrics
        accuracy_val = accuracy_score(y_test, y_test_pred)
        precision_val = precision_score(y_test, y_test_pred, average='weighted')
        recall_val = recall_score(y_test, y_test_pred, average='weighted')
        f1_val = f1_score(y_test, y_test_pred, average='weighted')



        dt = DecisionTreeClassifier(random_state=42)
        dt.fit(X_train, y_train)

        # Compute permutation importance
        r = permutation_importance(dt, X_test, y_test, n_repeats=30, random_state=42)

        # Get sorted indices based on mean importance
        sorted_idx = r.importances_mean.argsort()

        # Print feature importances in order
        print("Feature Importances (sorted):")
        for i in sorted_idx[::-1]:
            print(f"{X_train.columns[i]:<12} "
                  f"{r.importances_mean[i]:.3f} "
                  f"+/- {r.importances_std[i]:.3f}")

        # Plot feature importances
        plt.figure(figsize=(10, 6))
        plt.barh(range(len(sorted_idx)), r.importances_mean[sorted_idx], xerr=r.importances_std[sorted_idx], align='center')
        plt.yticks(range(len(sorted_idx)), [X_train.columns[i] for i in sorted_idx])
        plt.xlabel('Mean Importance')
        plt.title('Permutation Importances (Decision Tree)')
        plt.gca().invert_yaxis()

        # Save the plot to a file
        plot_filename = "permutation_importances.png"
        plt.savefig(plot_filename)

        # Display the plot
        plt.show()

        if mlflow.active_run():
            mlflow.end_run()

        # Start a new MLflow run and log the plot
        with mlflow.start_run(nested=True):
            mlflow.log_artifact(plot_filename)

        # Clean up the saved plot file if necessary
        import os
        os.remove(plot_filename)
        mlflow.end_run()



        # Log metrics individually
        mlflow.log_metric("accuracy", accuracy_val)
        mlflow.log_metric("precision", precision_val)
        mlflow.log_metric("recall", recall_val)
        mlflow.log_metric("f1_score", f1_val)

        # Log metrics as a dictionary artifact
        metrics_dict = {
            "accuracy": accuracy_val,
            "precision": precision_val,
            "recall": recall_val,
            "f1_score": f1_val
        }
        mlflow.log_dict(metrics_dict, "model_metrics.json")

        # Log metrics in the logger
        logger.info(f"Model: {classifier.__class__.__name__}")
        logger.info("Model accuracy on test set: %0.4f%%", accuracy_val * 100)
        logger.info("Model precision on test set: %0.4f%%", precision_val * 100)
        logger.info("Model recall on test set: %0.4f%%", recall_val * 100)
        logger.info("Model F1 score on test set: %0.4f%%", f1_val * 100)
        
        results_dict['classifier'] = classifier.__class__.__name__
        results_dict['test_score'] = [accuracy_val, precision_val, recall_val, f1_val]

        run_id = mlflow.last_active_run().info.run_id
        logger.info(f"Logged train model in run {run_id}")

    return model, X_train.columns, results_dict





    