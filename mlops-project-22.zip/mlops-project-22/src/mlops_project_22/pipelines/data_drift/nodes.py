"""
This is a boilerplate pipeline
generated using Kedro 0.18.8
"""

import logging
from typing import Any, Dict, Tuple

import numpy as np
import pandas as pd


import matplotlib.pyplot as plt  
import nannyml as nml
from evidently.report import Report
from evidently.metric_preset import DataDriftPreset



import logging
import nannyml as nml
from evidently.report import Report
from evidently.metric_preset import DataDriftPreset

logger = logging.getLogger(__name__)



def data_drift(data_reference: pd.DataFrame, data_analysis: pd.DataFrame):
    # Define your categorical and continuous columns
    cat_cols = ['sex', 'exng', 'caa', 'cp', 'fbs', 'restecg', 'slp', 'thall']
    con_cols = ["age", "trtbps", "chol", "thalachh", "oldpeak"]

    # Results storage
    univariate_results = []

    # Iterate over categorical columns
    for cat_col in cat_cols:
        # Define the threshold for the test
        constant_threshold = nml.thresholds.ConstantThreshold(lower=None, upper=0.2)
        constant_threshold.thresholds(data_reference[cat_col])

        # Initialize the object for Univariate Drift calculations
        univariate_calculator = nml.UnivariateDriftCalculator(
            column_names=[cat_col],
            treat_as_categorical=[cat_col],
            chunk_size=50,
            categorical_methods=['jensen_shannon'],
            thresholds={"jensen_shannon": constant_threshold}
        )

        univariate_calculator.fit(data_reference)
        results = univariate_calculator.calculate(data_analysis).filter(period='analysis', column_names=[cat_col], methods=['jensen_shannon']).to_df()
        univariate_results.append(results)
        

        # Generate a drift plot for the current categorical column
        figure = univariate_calculator.calculate(data_analysis).filter(period='analysis', column_names=[cat_col], methods=['jensen_shannon']).plot(kind='drift')
        figure.write_html(f"data/08_reporting/univariate_nml_{cat_col}.html")

    # Combine all univariate results into one DataFrame
    univariate_results_df = pd.concat(univariate_results, axis=0)
    univariate_results_df = pd.DataFrame(univariate_results_df)

    # Generate a report for continuous features using Evidently AI with KS test
    data_drift_report = Report(metrics=[
        DataDriftPreset(num_stattest='ks', stattest_threshold=0.05)
    ])
    data_drift_report.run(current_data=data_analysis[con_cols], reference_data=data_reference[con_cols], column_mapping=None)
    data_drift_report.save_html("data/08_reporting/data_drift_report.html")

    # Multivariate Drift using Data Reconstruction Drift Calculator
    multi_drift_calculator = nml.drift.multivariate.data_reconstruction.calculator.DataReconstructionDriftCalculator(
        column_names=con_cols + cat_cols,
        n_components=0.65,
        chunk_size=50
    )

    multi_drift_calculator.fit(data_reference)
    multi_drift_results = multi_drift_calculator.calculate(data_analysis).to_df()

    # Generate a reconstruction error drift plot
    figure = multi_drift_calculator.calculate(data_analysis).plot()
    figure.write_html("data/08_reporting/multivariate_data_reconstruction_drift.html")

    return univariate_results_df, multi_drift_results