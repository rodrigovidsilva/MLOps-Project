"""
This is a boilerplate pipeline
generated using Kedro 0.18.8
"""

from kedro.pipeline import Pipeline, node, pipeline
from .nodes import data_drift

def create_pipeline(**kwargs) -> Pipeline:
    return pipeline(
        [
            node(
                func=data_drift,
                inputs=["ref_heart", "ana_heart"],
                outputs=["univariate_results", "multi_drift_results"],
                name="data_drift_node",
            ),
        ]
    )