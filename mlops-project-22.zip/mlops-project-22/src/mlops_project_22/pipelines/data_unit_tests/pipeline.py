from kedro.pipeline import Pipeline, node, pipeline
from .nodes import test_data, verify_data_unit_tests, feature_store

def create_pipeline(**kwargs) -> Pipeline:
    return pipeline(
        [
            node(
                func= test_data,
                inputs="heart",
                outputs= "heart_tests",
                name="heart_data_unit_tests",
            ),
            node(
                func= verify_data_unit_tests,
                inputs="heart_tests",
                outputs= None, 
                name="verify_heart_data_unit_tests",
            ),

            node(
                func= test_data,
                inputs="heart_additional",
                outputs= "heart_additional_tests",
                name="heart_additional_data_unit_tests",
            ),
            node(
                func= verify_data_unit_tests,
                inputs="heart_additional_tests",
                outputs= None, 
                name="verify_heart_additional_data_unit_tests",
            ),
            node(
                func= feature_store,
                inputs="ingested",
                outputs= None, 
                name="feature_store_bronze",
            )

        ]
    )