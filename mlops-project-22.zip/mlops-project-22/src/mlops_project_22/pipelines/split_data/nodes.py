"""
This is a boilerplate pipeline 'split_data'
generated using Kedro 0.19.6
"""
import numpy as np
import pandas as pd


def split_heart_random(df):

    ref_heart = df.sample(frac=0.8,random_state=42)
    ana_heart = df.drop(ref_heart.index)

    return ref_heart, ana_heart
