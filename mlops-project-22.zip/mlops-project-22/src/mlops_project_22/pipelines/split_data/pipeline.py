"""
This is a boilerplate pipeline 'split_data'
generated using Kedro 0.19.6
"""

from kedro.pipeline import Pipeline, node, pipeline
from .nodes import split_heart_random

def create_pipeline(**kwargs) -> Pipeline:
    return pipeline([node(
                func= split_heart_random,
                inputs="ingested",
                outputs=["ref_heart", "ana_heart"],
                name="split_ingested_random_node",
            )])
