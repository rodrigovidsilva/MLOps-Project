"""
This is a boilerplate pipeline 'preprocessing_train'
generated using Kedro 0.19.6
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import RobustScaler, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report
import logging
#from ydata_profiling.expectations_report import ExpectationsReport
import pandas as pd
from visions import VisionsTypeset
import pandas as pd
from datetime import datetime
from typing import Any, Optional, Tuple, Dict
from great_expectations.core import ExpectationSuite, ExpectationConfiguration
from sklearn.model_selection import GridSearchCV
from scipy.stats import zscore
import hopsworks
import great_expectations as gx
import warnings
warnings.filterwarnings("ignore")
logger = logging.getLogger(__name__)

def clean_data(data: pd.DataFrame):
    # Drop duplicate rows
    df_transformed = data.drop_duplicates()


    describe_to_dict_verified = df_transformed.describe().to_dict()

    return df_transformed, describe_to_dict_verified 

def build_expectation_suite_feature(expectation_suite_name: str, feature_group: str) -> ExpectationSuite:
    expectation_suite = ExpectationSuite(expectation_suite_name=expectation_suite_name)
    columns = {
        'client_features': ['age', 'sex'],
        'health_features': ['cp', 'trtbps', 'chol', 'fbs', 'restecg', 'thalachh', 'exng', 'oldpeak', 'slp', 'caa', 'thall'],
        'target_feature': ['output']
    }
    
    for column in columns.get(feature_group, []):
        expectation_suite.add_expectation(
            ExpectationConfiguration(
                expectation_type="expect_column_values_to_be_of_type",
                kwargs={"column": column, "type_": "int64" if column != 'oldpeak' else 'float64'}
            )
        )
    return expectation_suite

def to_feature_store(
    data: pd.DataFrame,
    group_name: str,
    feature_group_version: int,
    description: str,
    group_description: dict,
    validation_expectation_suite: ExpectationSuite,
    ):
    """
    This function takes in a pandas DataFrame and a validation expectation suite,
    performs validation on the data using the suite, and then saves the data to a
    feature store in the feature store.

    Args:
        data (pd.DataFrame): Dataframe with the data to be stored
        group_name (str): Name of the feature group.
        feature_group_version (int): Version of the feature group.
        description (str): Description for the feature group.
        group_description (dict): Description of each feature of the feature group. 
        validation_expectation_suite (ExpectationSuite): group of expectations to check data.
        SETTINGS (dict): Dictionary with the settings definitions to connect to the project.
        
    Returns:
        A dictionary with the feature view version, feature view name and training dataset feature version.
    
    
    """
    # Connect to feature store.
    project = hopsworks.login(
        api_key_value="0fuOFPhQEG4nZN0u.UIqun0lLMRftWXuChCNoBZY0cgH8GJHP4csDzfAulPkivnK9Rl4XCbkazeUrbvmg", project="MLOps_Hospital_1"
    )
    feature_store = project.get_feature_store()

    # Create feature group.
    object_feature_group = feature_store.get_or_create_feature_group(
        name=group_name,
        version=feature_group_version,
        description= description,
        primary_key=["index"],
        online_enabled=False,
        expectation_suite=validation_expectation_suite,
    )
    # Upload data.
    object_feature_group.insert(
        features=data,
        overwrite=False,
        write_options={
            "wait_for_job": True,
        },
    )

    # Add feature descriptions.

    for description in group_description:
        object_feature_group.update_feature_description(
            description["name"], description["description"]
        )

    # Update statistics.
    object_feature_group.statistics_config = {
        "enabled": True,
        "histograms": True,
        "correlations": True,
    }
    object_feature_group.update_statistics_config()
    object_feature_group.compute_statistics()

    return object_feature_group

def feature_store(ingested):
    health_features = ['cp', 'trtbps', 'chol', 'fbs', 'restecg', 'thalachh', 'exng', 'oldpeak', 'slp', 'caa', 'thall']
    client_features = ['sex','age']

    validation_expectation_suite_client = build_expectation_suite_feature("client_expectations", "silver_client_features")
    validation_expectation_suite_target = build_expectation_suite_feature("target_expectations", "silver_target_features")
    validation_expectation_suite_health = build_expectation_suite_feature("health_expectations", "silver_health_features")

    health_feature_descriptions =[]
    client_feature_descriptions =[]
    target_feature_descriptions =[]
    
    ingested_health = ingested[["index"] + health_features]
    ingested_client = ingested[["index"] + client_features]
    ingested_target = ingested[["index"] + ["output"]]

    if False:

        object_fs_health_features = to_feature_store(
            ingested_health,"silver_health_features",
            1,"Health Features",
            health_feature_descriptions,
            validation_expectation_suite_health
        )

        object_fs_client_features = to_feature_store(
            ingested_client,"silver_client_features",
            1,"Client Features",
            client_feature_descriptions,
            validation_expectation_suite_client
        )

        object_fs_taregt_features = to_feature_store(
            ingested_target,"silver_target_feature",
            1,"Target Feature",
            target_feature_descriptions,
            validation_expectation_suite_target,
        )


def create_feat(df: pd.DataFrame) -> pd.DataFrame:
    age_bins = [0, 30, 50, 65, 80, 100, 115]
    bp_bins = [0, 120, 140, 160, 180, 200]

    df['age_bin'] = pd.cut(df['age'], bins=age_bins, labels=['0-30', '31-50', '50-65', '65-80', '80-100', '100-115'])
    df['bp_bin'] = pd.cut(df['trtbps'], bins=bp_bins, labels=['0-120', '121-140', '141-160', '161-180', '181-200'])

    # Creating the profile identifier
    df['profile'] = df['age_bin'].astype(str) + '_' + df['bp_bin'].astype(str)

    # Apply Z-score normalization to the cholesterol column
    df['chol_zscore'] = zscore(df['chol'])
    df = df.drop(columns=['profile', 'age_bin', 'bp_bin'])
    return df

def build_expectation_suite_feature_gold(expectation_suite_name: str, feature_group: str) -> ExpectationSuite:
    expectation_suite = ExpectationSuite(expectation_suite_name=expectation_suite_name)
    columns = {
        'client_features': ['age', 'sex_1'],
        'health_features': ['cp_1','cp_2','cp_3', 'trtbps', 'chol', 'fbs_1', 'restecg_1','restecg_2', 'thalachh', 'exng_1', 'oldpeak', 'slp_1','slp_2', 'caa_1','caa_2','caa_3','caa_4', 'thall_1','thall_2','thall_3','chol_zscore'],
        'target_feature': ['output']
    }

    
    for column in columns.get(feature_group, []):
        expectation_suite.add_expectation(
            ExpectationConfiguration(
                expectation_type="expect_column_values_to_be_of_type",
                kwargs={"column": column, "type_": "int64" if column != 'oldpeak' else 'float64'}
            )
        )
    return expectation_suite

def to_feature_store_gold(
    data: pd.DataFrame,
    group_name: str,
    feature_group_version: int,
    description: str,
    group_description: dict,
    validation_expectation_suite: ExpectationSuite,
    ):
    """
    This function takes in a pandas DataFrame and a validation expectation suite,
    performs validation on the data using the suite, and then saves the data to a
    feature store in the feature store.

    Args:
        data (pd.DataFrame): Dataframe with the data to be stored
        group_name (str): Name of the feature group.
        feature_group_version (int): Version of the feature group.
        description (str): Description for the feature group.
        group_description (dict): Description of each feature of the feature group. 
        validation_expectation_suite (ExpectationSuite): group of expectations to check data.
        SETTINGS (dict): Dictionary with the settings definitions to connect to the project.
        
    Returns:
        A dictionary with the feature view version, feature view name and training dataset feature version.
    
    
    """
    # Connect to feature store.
    project = hopsworks.login(
        api_key_value="0fuOFPhQEG4nZN0u.UIqun0lLMRftWXuChCNoBZY0cgH8GJHP4csDzfAulPkivnK9Rl4XCbkazeUrbvmg", project="MLOps_Hospital_1"
    )
    feature_store_gold = project.get_feature_store()

    # Create feature group.
    object_feature_group = feature_store_gold.get_or_create_feature_group(
        name=group_name,
        version=feature_group_version,
        description= description,
        primary_key=["index"],
        online_enabled=False,
        expectation_suite=validation_expectation_suite,
    )
    # Upload data.
    object_feature_group.insert(
        features=data,
        overwrite=False,
        write_options={
            "wait_for_job": True,
        },
    )

    # Add feature descriptions.

    for description in group_description:
        object_feature_group.update_feature_description(
            description["name"], description["description"]
        )

    # Update statistics.
    object_feature_group.statistics_config = {
        "enabled": True,
        "histograms": True,
        "correlations": True,
    }
    object_feature_group.update_statistics_config()
    object_feature_group.compute_statistics()

    return object_feature_group

def feature_store_gold(ingested):
    health_features = ['cp_1','cp_2','cp_3', 'trtbps', 'chol', 'fbs_1', 'restecg_1','restecg_2', 'thalachh', 'exng_1', 'oldpeak', 'slp_1','slp_2', 'caa_1','caa_2','caa_3','caa_4', 'thall_1','thall_2','thall_3','chol_zscore']
    client_features = ['sex_1','age']

    validation_expectation_suite_client = build_expectation_suite_feature_gold("client_expectations", "gold_client_features")
    validation_expectation_suite_target = build_expectation_suite_feature_gold("target_expectations", "gold_target_features")
    validation_expectation_suite_health = build_expectation_suite_feature_gold("health_expectations", "gold_health_features")

    health_feature_descriptions =[]
    client_feature_descriptions =[]
    target_feature_descriptions =[]
    
    ingested_health = ingested[["index"] + health_features]
    ingested_client = ingested[["index"] + client_features]
    ingested_target = ingested[["index"] + ["output"]]

    if False:

        object_fs_health_features = to_feature_store(
            ingested_health,"gold_health_features",
            1,"Health Features",
            health_feature_descriptions,
            validation_expectation_suite_health
        )

        object_fs_client_features = to_feature_store(
            ingested_client,"gold_client_features",
            1,"Client Features",
            client_feature_descriptions,
            validation_expectation_suite_client
        )

        object_fs_taregt_features = to_feature_store(
            ingested_target,"gold_target_feature",
            1,"Target Feature",
            target_feature_descriptions,
            validation_expectation_suite_target,
        )

def build_expectation_suite(expectation_suite_name: str, add_data) -> ExpectationSuite:
    """
    Builder used to retrieve an instance of the validation expectation suite.
    
    Args:
        expectation_suite_name (str): A dictionary with the feature group name and the respective version.
        add_data: New data entering.
             
    Returns:
        ExpectationSuite: A dictionary containing all the expectations for this particular feature group.
    """


    
    context = gx.get_context(context_root_dir = "gx")

    datasource_name = "hospital_datasource"
    try:
        datasource = context.sources.add_pandas(datasource_name)
    except:
        print("Data Source already exists.")
        datasource = context.datasources[datasource_name]

    suite_bank = context.add_or_update_expectation_suite(expectation_suite_name=expectation_suite_name)

    expectation_age = ExpectationConfiguration(
    expectation_type="expect_column_values_to_be_between",
    kwargs={
        "column": "age",
        "max_value": 115,
        "min_value": 0
    },
    )   
    suite_bank.add_expectation(expectation_configuration=expectation_age)

    expectation_sex = ExpectationConfiguration(
    expectation_type="expect_column_distinct_values_to_be_in_set",
    kwargs={
        "column": "sex",
        "value_set" : [0,1]
    },
    )
    suite_bank.add_expectation(expectation_configuration=expectation_sex)

    expectation_cp = ExpectationConfiguration(
    expectation_type="expect_column_distinct_values_to_be_in_set",
    kwargs={
        "column": "cp",
        "value_set" : [3, 2, 1, 0]
    },
    )
    suite_bank.add_expectation(expectation_configuration=expectation_cp)

    expectation_trtbps = ExpectationConfiguration(
    expectation_type="expect_column_values_to_be_between",
    kwargs={
        "column": "trtbps",
        "max_value": 196,
        "min_value": 80
    },
    )
    suite_bank.add_expectation(expectation_configuration=expectation_trtbps)

    expectation_chol = ExpectationConfiguration(
    expectation_type="expect_column_values_to_be_between",
    kwargs={
        "column": "chol",
        "max_value": 600,
        "min_value": 30
    },
    )
    suite_bank.add_expectation(expectation_configuration=expectation_chol)

    expectation_fbs = ExpectationConfiguration(
    expectation_type="expect_column_distinct_values_to_be_in_set",
    kwargs={
        "column": "fbs",
        "value_set" : [0,1]
    },
    )
    suite_bank.add_expectation(expectation_configuration=expectation_fbs)

    expectation_restecg = ExpectationConfiguration(
    expectation_type="expect_column_distinct_values_to_be_in_set",
    kwargs={
        "column": "restecg",
        "value_set" : [0,1,2]
    },
    )
    suite_bank.add_expectation(expectation_configuration=expectation_restecg)

    expectation_thalachh = ExpectationConfiguration(
    expectation_type="expect_column_values_to_be_between",
    kwargs={
        "column": "thalachh",
        "max_value": 290,
        "min_value": 50
    },
    )
    suite_bank.add_expectation(expectation_configuration=expectation_thalachh)

    expectation_exng = ExpectationConfiguration(
    expectation_type="expect_column_distinct_values_to_be_in_set",
    kwargs={
        "column": "exng",
        "value_set" : [0,1]
    },
    )   
    suite_bank.add_expectation(expectation_configuration=expectation_exng)

    expectation_oldpeak = ExpectationConfiguration(
    expectation_type="expect_column_values_to_be_between",
    kwargs={
        "column": "oldpeak",
        "max_value": 7.0,
        "min_value": 0.0
    },
    )
    suite_bank.add_expectation(expectation_configuration=expectation_oldpeak)

    expectation_slp = ExpectationConfiguration(
    expectation_type="expect_column_distinct_values_to_be_in_set",
    kwargs={
        "column": "slp",
        "value_set" : [0,1,2]
    },
    )
    suite_bank.add_expectation(expectation_configuration=expectation_slp)

    expectation_caa = ExpectationConfiguration(
    expectation_type="expect_column_distinct_values_to_be_in_set",
    kwargs={
        "column": "caa",
        "value_set" : [0,1,2,3,4]
    },
    )
    suite_bank.add_expectation(expectation_configuration=expectation_caa)

    expectation_thall = ExpectationConfiguration(
    expectation_type="expect_column_distinct_values_to_be_in_set",
    kwargs={
        "column": "thall",
        "value_set" : [0,1,2,3]
    },
    )
    suite_bank.add_expectation(expectation_configuration=expectation_thall)

    expectation_output = ExpectationConfiguration(
    expectation_type="expect_column_distinct_values_to_be_in_set",
    kwargs={
        "column": "output",
        "value_set" : ['0','1']
    },
    )
    suite_bank.add_expectation(expectation_configuration=expectation_output)

    context.save_expectation_suite(expectation_suite=suite_bank)

    data_asset_name = "Reference Data"
    try:
        data_asset = datasource.add_dataframe_asset(name=data_asset_name, dataframe=add_data)
    except:
        print("The data asset already exists. The required one will be loaded.")
        data_asset = datasource.get_asset(data_asset_name)

    batch_request = data_asset.build_batch_request(dataframe=add_data)

    checkpoint = gx.checkpoint.SimpleCheckpoint(
        name="checkpoint_expectations",
        data_context=context,
        validations=[
            {
            "batch_request": batch_request,
            "expectation_suite_name": "Hospital",
            },
        ],
    )
    checkpoint_result = checkpoint.run()

    return checkpoint_result

def get_validation_results(checkpoint_result):
    # validation_result is a dictionary containing one key-value pair
    validation_result_key, validation_result_data = next(iter(checkpoint_result["run_results"].items()))

    # Accessing the 'actions_results' from the validation_result_data
    validation_result_ = validation_result_data.get('validation_result', {})

    # Accessing the 'results' from the validation_result_data
    results = validation_result_["results"]
    meta = validation_result_["meta"]
    use_case = meta.get('expectation_suite_name')
    
    
    df_validation = pd.DataFrame({},columns=["Success","Expectation Type","Column","Column Pair","Max Value",\
                                       "Min Value","Element Count","Unexpected Count","Unexpected Percent","Value Set","Unexpected Value","Observed Value"])
    
    
    for result in results:
        # Process each result dictionary as needed
        success = result.get('success', '')
        expectation_type = result.get('expectation_config', {}).get('expectation_type', '')
        column = result.get('expectation_config', {}).get('kwargs', {}).get('column', '')
        column_A = result.get('expectation_config', {}).get('kwargs', {}).get('column_A', '')
        column_B = result.get('expectation_config', {}).get('kwargs', {}).get('column_B', '')
        value_set = result.get('expectation_config', {}).get('kwargs', {}).get('value_set', '')
        max_value = result.get('expectation_config', {}).get('kwargs', {}).get('max_value', '')
        min_value = result.get('expectation_config', {}).get('kwargs', {}).get('min_value', '')

        element_count = result.get('result', {}).get('element_count', '')
        unexpected_count = result.get('result', {}).get('unexpected_count', '')
        unexpected_percent = result.get('result', {}).get('unexpected_percent', '')
        observed_value = result.get('result', {}).get('observed_value', '')
        if type(observed_value) is list:
            #sometimes observed_vaue is not iterable
            unexpected_value = [item for item in observed_value if item not in value_set]
        else:
            unexpected_value=[]
        
        df_validation = pd.concat([df_validation, pd.DataFrame.from_dict( [{"Success" :success,"Expectation Type" :expectation_type,"Column" : column,"Column Pair" : (column_A,column_B),"Max Value" :max_value,\
                                           "Min Value" :min_value,"Element Count" :element_count,"Unexpected Count" :unexpected_count,"Unexpected Percent":unexpected_percent,\
                                                  "Value Set" : value_set,"Unexpected Value" :unexpected_value ,"Observed Value" :observed_value}])], ignore_index=True)
        
    return df_validation


def test_data(df):
    context = gx.get_context(context_root_dir = "gx")
    datasource_name = "hospital_datasource"
    try:
        datasource = context.sources.add_pandas(datasource_name)
        logger.info("Data Source created.")
    except:
        logger.info("Data Source already exists.")
        datasource = context.datasources[datasource_name]

    suite_bank = context.add_or_update_expectation_suite(expectation_suite_name="Hospital")
    
    expectation_age = ExpectationConfiguration(
    expectation_type="expect_column_values_to_be_between",
    kwargs={
        "column": "age",
        "max_value": 115,
        "min_value": 0
    },
    )   
    suite_bank.add_expectation(expectation_configuration=expectation_age)

    expectation_sex = ExpectationConfiguration(
    expectation_type="expect_column_distinct_values_to_be_in_set",
    kwargs={
        "column": "sex",
        "value_set" : [0,1]
    },
    )
    suite_bank.add_expectation(expectation_configuration=expectation_sex)

    expectation_cp = ExpectationConfiguration(
    expectation_type="expect_column_distinct_values_to_be_in_set",
    kwargs={
        "column": "cp",
        "value_set" : [3, 2, 1, 0]
    },
    )
    suite_bank.add_expectation(expectation_configuration=expectation_cp)

    expectation_trtbps = ExpectationConfiguration(
    expectation_type="expect_column_values_to_be_between",
    kwargs={
        "column": "trtbps",
        "max_value": 196,
        "min_value": 80
    },
    )
    suite_bank.add_expectation(expectation_configuration=expectation_trtbps)

    expectation_chol = ExpectationConfiguration(
    expectation_type="expect_column_values_to_be_between",
    kwargs={
        "column": "chol",
        "max_value": 600,
        "min_value": 30
    },
    )
    suite_bank.add_expectation(expectation_configuration=expectation_chol)

    expectation_fbs = ExpectationConfiguration(
    expectation_type="expect_column_distinct_values_to_be_in_set",
    kwargs={
        "column": "fbs",
        "value_set" : [0,1]
    },
    )
    suite_bank.add_expectation(expectation_configuration=expectation_fbs)

    expectation_restecg = ExpectationConfiguration(
    expectation_type="expect_column_distinct_values_to_be_in_set",
    kwargs={
        "column": "restecg",
        "value_set" : [0,1,2]
    },
    )
    suite_bank.add_expectation(expectation_configuration=expectation_restecg)

    expectation_thalachh = ExpectationConfiguration(
    expectation_type="expect_column_values_to_be_between",
    kwargs={
        "column": "thalachh",
        "max_value": 290,
        "min_value": 50
    },
    )
    suite_bank.add_expectation(expectation_configuration=expectation_thalachh)

    expectation_exng = ExpectationConfiguration(
    expectation_type="expect_column_distinct_values_to_be_in_set",
    kwargs={
        "column": "exng",
        "value_set" : [0,1]
    },
    )   
    suite_bank.add_expectation(expectation_configuration=expectation_exng)

    expectation_oldpeak = ExpectationConfiguration(
    expectation_type="expect_column_values_to_be_between",
    kwargs={
        "column": "oldpeak",
        "max_value": 7.0,
        "min_value": 0.0
    },
    )
    suite_bank.add_expectation(expectation_configuration=expectation_oldpeak)

    expectation_slp = ExpectationConfiguration(
    expectation_type="expect_column_distinct_values_to_be_in_set",
    kwargs={
        "column": "slp",
        "value_set" : [0,1,2]
    },
    )
    suite_bank.add_expectation(expectation_configuration=expectation_slp)

    expectation_caa = ExpectationConfiguration(
    expectation_type="expect_column_distinct_values_to_be_in_set",
    kwargs={
        "column": "caa",
        "value_set" : [0,1,2,3,4]
    },
    )
    suite_bank.add_expectation(expectation_configuration=expectation_caa)

    expectation_thall = ExpectationConfiguration(
    expectation_type="expect_column_distinct_values_to_be_in_set",
    kwargs={
        "column": "thall",
        "value_set" : [0,1,2,3]
    },
    )
    suite_bank.add_expectation(expectation_configuration=expectation_thall)

    expectation_output = ExpectationConfiguration(
    expectation_type="expect_column_distinct_values_to_be_in_set",
    kwargs={
        "column": "output",
        "value_set" : ['0','1']
    },
    )
    suite_bank.add_expectation(expectation_configuration=expectation_output)


    context.add_or_update_expectation_suite(expectation_suite=suite_bank)

    data_asset_name = "test"
    try:
        data_asset = datasource.add_dataframe_asset(name=data_asset_name, dataframe= df)
    except:
        logger.info("The data asset alread exists. The required one will be loaded.")
        data_asset = datasource.get_asset(data_asset_name)

    batch_request = data_asset.build_batch_request(dataframe= df)

    checkpoint = gx.checkpoint.SimpleCheckpoint(
        name="checkpoint_expectations",
        data_context=context,
        validations=[
            {   
                "batch_request": batch_request,
                "expectation_suite_name": "Hospital",
            },
        ],
    )
    checkpoint_result = checkpoint.run()

    df_validation = get_validation_results(checkpoint_result)
    #base on these results you can make an assert to stop your pipeline

    pd_df_ge = gx.from_pandas(df)


    assert pd_df_ge.expect_column_to_exist("age").success == True
    assert pd_df_ge.expect_column_to_exist("sex").success == True
    assert pd_df_ge.expect_column_to_exist("cp").success == True
    assert pd_df_ge.expect_column_to_exist("trtbps").success == True
    assert pd_df_ge.expect_column_to_exist("chol").success == True
    assert pd_df_ge.expect_column_to_exist("fbs").success == True
    assert pd_df_ge.expect_column_to_exist("restecg").success == True
    assert pd_df_ge.expect_column_to_exist("thalachh").success == True
    assert pd_df_ge.expect_column_to_exist("exng").success == True
    assert pd_df_ge.expect_column_to_exist("oldpeak").success == True
    assert pd_df_ge.expect_column_to_exist("slp").success == True
    assert pd_df_ge.expect_column_to_exist("caa").success == True
    assert pd_df_ge.expect_column_to_exist("thall").success == True
    assert pd_df_ge.expect_column_to_exist("chol_zscore").success == True
    assert pd_df_ge.expect_column_to_exist("output").success == True


    


    log = logging.getLogger(__name__)
    log.info("Data passed on the unit data tests")
  

    return df_validation



def verify_data_unit_tests(df_validation):
    '''
    Indentify where the data unit tests failed
    '''
    log = logging.getLogger(__name__)

    for index, row in df_validation.iterrows():
        if row["Success"]==False:
            log.info("Data Unit Tests failed: ")
            log.info(df_validation.iloc[index])

def encode_and_scale(df: pd.DataFrame) -> pd.DataFrame:
    cat_cols = ['sex', 'exng', 'caa', 'cp', 'fbs', 'restecg', 'slp', 'thall']
    con_cols = ["age", "trtbps", "chol", "thalachh", "oldpeak", "chol_zscore"]

    # Encoding the categorical columns
    df = pd.get_dummies(df, columns=cat_cols, drop_first=True)
    df = df.replace({False: 0, True: 1})
    
    # Scaling the continuous columns
    scaler = StandardScaler()
    df[con_cols] = scaler.fit_transform(df[con_cols])
    
    logging.info(f"Data after encoding and scaling has {df.shape[1]} columns.")
    return df

def feature_engineer(df: pd.DataFrame):
    df = create_feat(df)
    df = encode_and_scale(df)
    return df

