"""
This is a boilerplate pipeline 'preprocessing_train'
generated using Kedro 0.19.6
"""

from kedro.pipeline import Pipeline, node, pipeline
from .nodes import feature_engineer, clean_data, feature_store, verify_data_unit_tests, test_data, feature_store_gold, create_feat

def create_pipeline(**kwargs) -> Pipeline:
    return pipeline([node(
                func= clean_data,
                inputs="ref_heart",
                outputs= ["ref_heart_cleaned","reporting_data_train"],
                name="clean_data",
            ),
            node(
                func= feature_store,
                inputs="ref_heart_cleaned",
                outputs= None, 
                name="feature_store_silver",
            ),
            node(
                func= create_feat,
                inputs="ref_heart_cleaned",
                outputs= "preprocessed_training_data_not_scaled",
                name="preprocessed_training_with_out_scaling",
            ),
            node(
                func= feature_engineer,
                inputs="ref_heart_cleaned",
                outputs= "preprocessed_training_data",
                name="preprocessed_training",
            ),
            node(
                func= feature_store_gold,
                inputs="preprocessed_training_data",
                outputs= None, 
                name="feature_store_gold",
            ),
            node(
                func= test_data,
                inputs="preprocessed_training_data_not_scaled",
                outputs= "preprocessed_training_data_tests",
                name="preprocessed_training_data_unit_tests",
            ),
            node(
                func= verify_data_unit_tests,
                inputs="preprocessed_training_data_tests",
                outputs= None, 
                name="verify_preprocessed_training_data_tests_data_unit_tests",
            )
            ])
